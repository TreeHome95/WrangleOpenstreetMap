OSMFILE = 'brooklyn.osm'
street_type_re = re.compile(r'\b\S+\.?$', re.IGNORECASE)


expected = ["Street", "Avenue", "Boulevard", "Drive", "Court", "Place", "Square", "Lane", "Road", 
            "Trail", "Parkway", "Commons"] # Expected values


mapping = { "St": "Street",
            "Ave" : "Avenue",
            "Rd" : "Road",
            "W" : "West",
            "E" : "East" 
            } # mapping values, in this case the abbreviated values mapped to their unabbreviated versions.


def audit_street_type(street_types, street_name): # if the street name doesn't match the expected value then it is added to a group by its street type
    m = street_type_re.search(street_name)
    if m:
        street_type = m.group()
        if street_type not in expected:
            street_types[street_type].add(street_name)


def is_street_name(elem): 
    return (elem.attrib['k'] == "addr:street") # returns true if key matches "addr:street". This is to specifically target street names.


def audit(osmfile):
    osm_file = open(osmfile, "r") #open osm file
    street_types = defaultdict(set)
    for event, elem in ET.iterparse(osm_file, events=("start",)): #iterparse through every element.

        if elem.tag == "node" or elem.tag == "way": # check if the element is a node or way.
            for tag in elem.iter("tag"):            # iterate through the tag
                if is_street_name(tag):             # if its a street name then audit 
                    audit_street_type(street_types, tag.attrib['v'])
    osm_file.close() #close the osm file
    return street_types


def update_name(name, mapping):
    words = name.split() # splits street name by word
    for w in range(len(words)): #iterates through the words 
        if words[w] in mapping: # check if word is in mapping values
            if words[w*1].lower() not in ['suite', 'ste.', 'ste']:  
                # For example, don't update 'Suite E' to 'Suite East
                words[w] = mapping[words[w]] # correct the word
                name = " ".join(words) # join to undo the split
    return name


def test():
    st_types = audit(OSMFILE)
    pprint.pprint(dict(st_types))

    for st_type, ways in st_types.iteritems():
        for name in ways:
            better_name = update_name(name, mapping)
            print name, "=>", better_name # Will print out  "name => better_name"
            


if __name__ == '__main__':
    test() # Data was inconsistent with street names, example Avenues would vary between using Avenue and the abbreviation Ave.