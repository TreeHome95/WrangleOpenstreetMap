brooklyn.osm - The openstreetmap file of Brooklyn,NY,USA. I'm from Brooklyn and wanted to see if I could find something I didn't know about it and I did.
Source: https://www.openstreetmap.org/export#map=11/40.6400/-73.9359

audit.py - Based of the audit functions in the openstreetmap case study lesson plan
Source: https://classroom.udacity.com/nanodegrees/nd002/parts/860b269a-d0b0-4f0c-8f3d-ab08865d43bf/modules/undefined/lessons/5436095827/concepts/8755386130923

schema.py - Based of the openstreetmap case study lesson plan
Source: https://classroom.udacity.com/nanodegrees/nd002/parts/860b269a-d0b0-4f0c-8f3d-ab08865d43bf/modules/316820862075461/lessons/5436095827/concepts/54908788190923

xml-to-csv-writer.py - Also based of the openstreetmap case study lesson plan.
Source: https://classroom.udacity.com/nanodegrees/nd002/parts/860b269a-d0b0-4f0c-8f3d-ab08865d43bf/modules/316820862075461/lessons/5436095827/concepts/54908788190923
notebook.pdf - A pdf version of the project. Six pages however, it didn't come out exactly
like the notebook version due to code highlighting not syncing.

openstreetmap-map-project.pdf - PDF version of the jupyter-notebook

nodes.csv, nodes_tags.csv, ways.csv, ways_nodes.csv, ways_tags.csv - all the ways nodes and tags in CSV format

brooklyn.db - all the csv files were imported into this database.

Other sources include the improvement to the update function I learned from reading: https://gist.github.com/carlward/54ec1c91b62a5f911c42#file-sample_project-md